"""
FIX OEMS - Order & Execution Management System
Professional Trading Dashboard (Tailwind CSS version)
"""

from datetime import datetime
import requests
import uuid as _uuid_lib

from dash import Dash, dcc, html, Input, Output, State, callback, dash_table, ctx
from dash import _dash_renderer

_dash_renderer._set_react_version("18.2.0")

# =============================================================================
# Configuration
# =============================================================================

API_BASE_URL = "http://localhost:8081/api"
REFRESH_MS = 2000

app = Dash(
    __name__,
    external_stylesheets=[],
    title="FIX OEMS - Trading Dashboard",
    suppress_callback_exceptions=True,
)

# Custom HTML template with Tailwind and Font Awesome
app.index_string = '''
<!DOCTYPE html>
<html>
    <head>
        {%metas%}
        <title>{%title%}</title>
        {%favicon%}
        {%css%}
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Tailwind CSS v3 -->
        <script src="https://cdn.tailwindcss.com"></script>
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
        <!-- Custom Tailwind config -->
        <script>
            tailwind.config = {
                theme: {
                    extend: {
                        colors: {
                            primary: '#1d4ed8',
                            success: '#059669',
                            danger: '#dc2626',
                            warning: '#d97706',
                            light: {
                                50:  '#f8fafc',
                                100: '#f1f5f9',
                                200: '#e2e8f0',
                                300: '#cbd5e1',
                                400: '#94a3b8',
                                500: '#64748b',
                            }
                        },
                        fontFamily: {
                            mono: ['ui-monospace', 'SFMono-Regular', 'Menlo', 'Monaco', 'Consolas', 'Liberation Mono', 'monospace'],
                            sans: ['Inter', 'system-ui', 'sans-serif'],
                        }
                    }
                }
            }
        </script>
        <style type="text/tailwindcss">
            @layer utilities {
                .content-auto {
                    content-visibility: auto;
                }
                .table-border-custom {
                    border: 1px solid rgba(0,0,0,0.07);
                }
                .table-header-bg {
                    background-color: rgba(0,0,0,0.03);
                }
                .btn-active {
                    @apply bg-primary text-slate-800;
                }
                .card-hover {
                    @apply hover:shadow-lg hover:shadow-primary/10 transition-all duration-200;
                }
            }
        </style>
    </head>
    <body class="bg-light-100 text-slate-800 font-sans min-h-screen">
        {%app_entry%}
        <footer>
            {%config%}
            {%scripts%}
            {%renderer%}
        </footer>
    </body>
</html>
'''

# =============================================================================
# Helpers (unchanged)
# =============================================================================

def safe_get_json(url: str, timeout: int = 2):
    try:
        r = requests.get(url, timeout=timeout)
        if r.status_code == 200:
            return r.json()
    except Exception:
        return None
    return None


def format_time(ts):
    if not ts:
        return ""
    if isinstance(ts, str):
        return ts[11:19] if len(ts) >= 19 else ts
    return str(ts)


def format_price(v):
    if v is None:
        return "MKT"
    try:
        fv = float(v)
        if fv <= 0:
            return "MKT"
        return f"${fv:.2f}"
    except Exception:
        return "MKT"


def normalize_orders_for_table(orders):
    out = []
    for o in orders or []:
        row = dict(o)
        row["timestamp"] = format_time(row.get("timestamp"))
        row["price"] = format_price(row.get("price"))
        row["filledQuantity"] = row.get("filledQuantity") or 0
        row["leavesQuantity"] = row.get("leavesQuantity")
        if row["leavesQuantity"] is None:
            row["leavesQuantity"] = row.get("quantity", 0)
        out.append(row)
    return out


def normalize_execs_for_table(execs):
    out = []
    for e in execs or []:
        row = dict(e)
        row["timestamp"] = format_time(row.get("timestamp"))

        lp = row.get("lastPrice")
        ap = row.get("avgPrice")

        try:
            row["lastPrice"] = f"${float(lp):.2f}" if lp and float(lp) > 0 else "-"
        except Exception:
            row["lastPrice"] = "-"

        try:
            row["avgPrice"] = f"${float(ap):.2f}" if ap and float(ap) > 0 else "-"
        except Exception:
            row["avgPrice"] = "-"

        out.append(row)
    return out

# =============================================================================
# Tailwind-styled UI Components
# =============================================================================

def top_bar():
    return html.Div(
        className="sticky top-0 z-10 border-b border-light-200 bg-white py-3 px-6 shadow-sm",
        children=html.Div(
            className="container mx-auto flex items-center justify-between",
            children=[
                # Left: Logo + Title
                html.Div(
                    className="flex items-center gap-3",
                    children=[
                        html.I(className="fa-solid fa-chart-line text-xl text-primary"),
                        html.Div(
                            className="flex flex-col",
                            children=[
                                html.Span("FIX OEMS", className="font-bold text-xl tracking-tight text-slate-800"),
                                html.Span("Trading Dashboard", className="text-light-400 text-xs tracking-wide"),
                            ]
                        ),
                    ],
                ),
                # Right: Connection status + Time
                html.Div(
                    className="flex items-center gap-6",
                    children=[
                        html.Span(
                            "DISCONNECTED",
                            id="connection-badge",
                            className="bg-danger text-slate-800 text-xs font-semibold px-4 py-1.5 rounded-full shadow-sm",
                        ),
                        html.Span(
                            id="header-time",
                            className="text-light-400 text-sm font-mono",
                        ),
                    ],
                ),
            ],
        ),
    )


def stat_card(title, value_id, color=None):
    """Enhanced stat card with better styling"""
    color_map = {
        "green": "text-success",
        "yellow": "text-warning",
        "blue": "text-primary",
        "gray": "text-light-400",
        "red": "text-danger",
    }
    
    bg_colors = {
        "green": "bg-white",
        "yellow": "bg-white",
        "blue": "bg-white",
        "gray": "bg-white",
        "red": "bg-white",
        None: "bg-white"
    }
    
    return html.Div(
        className=f"{bg_colors[color]} border border-light-200 rounded-lg p-4 shadow-sm card-hover",
        children=[
            html.Div(
                title,
                className="text-xs text-light-400 uppercase font-semibold tracking-wider mb-1"
            ),
            html.Div(
                "0",
                id=value_id,
                className=f"text-2xl font-bold mt-1 {color_map.get(color, 'text-slate-800')}"
            ),
        ],
    )


def stats_row():
    """Improved stats grid with responsive layout"""
    return html.Div(
        className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 mb-6",
        children=[
            stat_card("Total Orders", "stat-orders"),
            stat_card("Filled", "stat-filled", color="green"),
            stat_card("Partial", "stat-partial", color="yellow"),
            stat_card("Working", "stat-open", color="blue"),
            stat_card("Cancelled", "stat-cancelled", color="gray"),
            stat_card("Rejected", "stat-rejected", color="red"),
        ],
    )


def order_entry_panel():
    """Redesigned order entry panel with better spacing and styling"""
    return html.Div(
        className="bg-white border border-light-200 rounded-lg p-5 shadow-md card-hover",
        children=[
            # Header
            html.Div(
                className="flex items-center gap-2 mb-5 pb-3 border-b border-light-200",
                children=[
                    html.I(className="fa-solid fa-paper-plane text-primary"),
                    html.Span("Order Entry", className="font-bold text-lg")
                ],
            ),
            
            # Symbol Input
            html.Div(className="mb-4", children=[
                html.Label("Symbol", className="block text-xs text-light-400 mb-2 font-semibold"),
                dcc.Input(
                    id="symbol-input",
                    type="text",
                    placeholder="e.g. AAPL",
                    className="w-full bg-light-100 border border-light-300 rounded-md px-3 py-2 text-slate-800 uppercase font-bold focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all",
                ),
            ]),
            
            # Quantity + Price (two columns)
            html.Div(className="grid grid-cols-2 gap-4 mb-4", children=[
                html.Div([
                    html.Label("Quantity", className="block text-xs text-light-400 mb-2 font-semibold"),
                    dcc.Input(
                        id="quantity-input",
                        type="number",
                        min="100",
                        step="100",
                        placeholder="Shares",
                        className="w-full bg-light-100 border border-light-300 rounded-md px-3 py-2 text-slate-800 focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all",
                    ),
                ]),
                html.Div([
                    html.Label("Price", className="block text-xs text-light-400 mb-2 font-semibold"),
                    dcc.Input(
                        id="price-input",
                        type="number",
                        min="100",
                        step="5.00",
                        placeholder="Limit Price",
                        className="w-full bg-light-100 border border-light-300 rounded-md px-3 py-2 text-slate-800 focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all",
                    ),
                ]),
            ]),
            
            # Order Type dropdown
            html.Div(className="mb-4", children=[
                html.Label("Order Type", className="block text-xs text-light-400 mb-2 font-semibold"),
                dcc.Dropdown(
                    id="order-type-select",
                    options=[
                        {"label": "LIMIT", "value": "LIMIT"},
                        {"label": "MARKET", "value": "MARKET"},
                    ],
                    value="LIMIT",
                    className="w-full bg-light-100 border border-light-300 rounded-md text-slate-800 outline-none",
                    style={"backgroundColor": "#374151", "color": "#1e293b"},
                ),
            ]),

            # Network dropdown
            html.Div(className="mb-4", children=[
                html.Label(
                    className="flex items-center gap-1.5 text-xs text-light-400 mb-2 font-semibold",
                    children=[
                        html.I(className="fa-solid fa-network-wired text-primary/70"),
                        html.Span("Network"),
                    ],
                ),
                dcc.Dropdown(
                    id="network-select",
                    options=[
                        {"label": "🔷 Bloomberg",  "value": "BLOOMBERG"},
                        {"label": "⬛ NYFIX",      "value": "NYFIX"},
                        {"label": "🟦 Sungard",    "value": "SUNGARD"},
                        {"label": "🟩 Fidessa",    "value": "FIDESSA"},
                        {"label": "🟧 TradeWare",  "value": "TRADEWARE"},
                        {"label": "🟪 TradeWeb",   "value": "TRADEWEB"},
                        {"label": "⬜ CRD",        "value": "CRD"},
                    ],
                    placeholder="Select network…",
                    clearable=True,
                    className="w-full bg-light-100 border border-light-300 rounded-md placeholder-gray-400 text-slate-800 outline-none",
                    style={"backgroundColor": "#374151", "color": "#1e293b"},
                ),
            ]),

            # Broker Code dropdown (Bloomberg only)
            html.Div(
                id="broker-code-wrapper",
                style={"display": "none"},
                className="mb-4",
                children=[
                    html.Label(
                        className="flex items-center gap-1.5 text-xs text-primary mb-2 font-semibold",
                        children=[
                            html.I(className="fa-solid fa-building-columns text-primary/70"),
                            html.Span("Broker Code"),
                            html.Span("*", className="text-danger ml-0.5"),
                        ],
                    ),
                    dcc.Dropdown(
                        id="broker-code-select",
                        options=[
                            {"label": "BLOOMBERG MZUL",  "value": "MZUL"},
                            {"label": "BLOOMBERG MZOP",  "value": "MZOP"},
                            {"label": "BLOOMBERG MZPT",  "value": "MZPT"},
                            {"label": "BLOOMBERG IMET",  "value": "IMET"},
                        ],
                        placeholder="Select broker code…",
                        clearable=True,
                        className="w-full bg-light-100 border border-light-300 rounded-md text-slate-800 outline-none",
                        style={"backgroundColor": "#374151", "color": "#1e293b"},
                    ),
                ],
            ),

            # Bloomberg UUID field
            html.Div(
                id="uuid-wrapper",
                style={"display": "none"},
                className="mb-5",
                children=[
                    html.Label(
                        className="flex items-center gap-1.5 text-xs text-primary mb-2 font-semibold",
                        children=[
                            html.I(className="fa-solid fa-fingerprint text-primary/70"),
                            html.Span("Bloomberg UUID"),
                            html.Span("*", className="text-danger ml-0.5"),
                        ],
                    ),
                    html.Div(
                        className="relative flex items-center gap-2",
                        children=[
                            dcc.Input(
                                id="uuid-input",
                                type="text",
                                placeholder="e.g. 123e4567-e89b-12d3-a456-426614174000",
                                className="w-full bg-light-100 border border-light-300 rounded-md px-3 py-2 text-slate-800 font-mono text-xs focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all",
                            ),
                            html.Button(
                                html.I(className="fa-solid fa-rotate text-xs"),
                                id="uuid-generate-btn",
                                title="Generate new UUID",
                                className="shrink-0 bg-light-200 hover:bg-primary text-light-500 hover:text-slate-800 px-2.5 py-2 rounded-md transition-all",
                            ),
                        ],
                    ),
                    html.Div(
                        "Auto-populated — edit or regenerate as needed",
                        className="text-xs text-light-400 mt-1",
                    ),
                ],
            ),

            # OnBehalfOfCompID — tag 115 (NYFIX / TradeWare / TradeWeb)
            html.Div(
                id="onbehalf-wrapper",
                style={"display": "none"},
                className="mb-5",
                children=[
                    html.Label(
                        className="flex items-center gap-1.5 text-xs text-warning mb-2 font-semibold",
                        children=[
                            html.I(className="fa-solid fa-id-badge text-warning/70"),
                            html.Span("OnBehalfOfCompID"),
                            html.Span(" (tag 115)", className="text-light-400 font-normal ml-1"),
                            html.Span("*", className="text-danger ml-0.5"),
                        ],
                    ),
                    dcc.Input(
                        id="onbehalf-input",
                        type="text",
                        placeholder="e.g. CLIENTFIRM1",
                        className="w-full bg-light-100 border border-warning/30 rounded-md px-3 py-2 text-slate-800 font-mono text-xs focus:ring-2 focus:ring-warning/40 focus:border-warning/60 outline-none transition-all",
                    ),
                    html.Div(
                        "Required for routing via this network",
                        className="text-xs text-light-400 mt-1",
                    ),
                ],
            ),
            
            # ── Programme Trading toggle ──────────────────────────────
            html.Div(className="mb-4", children=[
                html.Div(
                    className="flex items-center justify-between bg-light-100 border border-light-300 rounded-md px-3 py-2",
                    children=[
                        html.Div(
                            className="flex items-center gap-2",
                            children=[
                                html.I(className="fa-solid fa-code-branch text-primary/70 text-xs"),
                                html.Span("Programme Trading", className="text-xs text-light-500 font-semibold"),
                            ],
                        ),
                        # Toggle switch built from dcc.Checklist styled as a pill
                        dcc.Checklist(
                            id="prog-trading-toggle",
                            options=[{"label": "", "value": "ON"}],
                            value=[],
                            inputStyle={
                                "width": "36px",
                                "height": "20px",
                                "cursor": "pointer",
                                "accentColor": "#165DFF",
                            },
                            className="flex items-center",
                        ),
                    ],
                ),
            ]),

            # ── ETF / CS switch ───────────────────────────────────────
            html.Div(className="mb-4", children=[
                html.Label("Instrument Type", className="block text-xs text-light-400 mb-2 font-semibold"),
                html.Div(
                    className="flex bg-light-100 rounded-md p-1 shadow-sm",
                    children=[
                        html.Button(
                            "CS",
                            id="instr-cs-btn",
                            n_clicks=0,
                            className="flex-1 py-1.5 text-xs font-bold rounded-md transition-all bg-primary text-slate-800",
                        ),
                        html.Button(
                            "ETF",
                            id="instr-etf-btn",
                            n_clicks=0,
                            className="flex-1 py-1.5 text-xs font-bold rounded-md transition-all hover:bg-primary/20 text-light-400",
                        ),
                    ],
                ),
                dcc.Store(id="instr-type-store", data="CS"),
            ]),

            # ── Currency selector ─────────────────────────────────────
            html.Div(className="mb-4", children=[
                html.Label(
                    className="flex items-center gap-1.5 text-xs text-light-400 mb-2 font-semibold",
                    children=[
                        html.I(className="fa-solid fa-coins text-primary/70"),
                        html.Span("Currency"),
                    ],
                ),
                dcc.Dropdown(
                    id="currency-select",
                    options=[
                        {"label": "🇺🇸 USD – US Dollar",        "value": "USD"},
                        {"label": "🇪🇺 EUR – Euro",              "value": "EUR"},
                        {"label": "🇬🇧 GBP – British Pound",     "value": "GBP"},
                        {"label": "🇯🇵 JPY – Japanese Yen",      "value": "JPY"},
                        {"label": "🇨🇭 CHF – Swiss Franc",       "value": "CHF"},
                        {"label": "🇭🇰 HKD – Hong Kong Dollar",  "value": "HKD"},
                        {"label": "🇸🇬 SGD – Singapore Dollar",  "value": "SGD"},
                        {"label": "🇨🇦 CAD – Canadian Dollar",   "value": "CAD"},
                        {"label": "🇦🇺 AUD – Australian Dollar", "value": "AUD"},
                    ],
                    value="USD",
                    clearable=False,
                    className="w-full bg-light-100 border border-light-300 rounded-md text-slate-800 outline-none",
                    style={"backgroundColor": "#374151", "color": "#1e293b"},
                ),
            ]),

            # Buy/Sell buttons
            html.Div(className="grid grid-cols-2 gap-4 mb-3", children=[
                html.Button(
                    "BUY",
                    id="buy-btn",
                    className="bg-success hover:bg-success/90 text-slate-800 font-bold py-2.5 px-4 rounded-md shadow-sm hover:shadow-md transition-all active:scale-95",
                ),
                html.Button(
                    "SELL",
                    id="sell-btn",
                    className="bg-danger hover:bg-danger/90 text-slate-800 font-bold py-2.5 px-4 rounded-md shadow-sm hover:shadow-md transition-all active:scale-95",
                ),
            ]),
            
            # Status message
            html.Div(id="order-status-msg", className="mt-2 text-sm rounded-md p-2"),
        ],
    )


def orders_blotter():
    """Redesigned orders blotter with improved table styling"""
    return html.Div(
        className="bg-white border border-light-200 rounded-lg p-5 shadow-md card-hover",
        children=[
            # Header with filter
            html.Div(
                className="flex flex-wrap items-center justify-between mb-5 pb-3 border-b border-light-200 gap-3",
                children=[
                    html.Div(
                        className="flex items-center gap-2",
                        children=[
                            html.I(className="fa-solid fa-list text-primary"),
                            html.Span("Orders Blotter", className="font-bold text-lg")
                        ],
                    ),
                    
                    # Filter buttons
                    html.Div(
                        className="flex bg-light-100 rounded-md p-1 shadow-sm",
                        children=[
                            html.Button(
                                "All",
                                id="orders-filter-all",
                                className="px-4 py-1.5 text-sm rounded-md transition-all hover:bg-primary/20 data-[active=true]:bg-primary data-[active=true]:text-slate-800",
                                **{"data-active": "true"},
                            ),
                            html.Button(
                                "Working",
                                id="orders-filter-working",
                                className="px-4 py-1.5 text-sm rounded-md transition-all hover:bg-primary/20 data-[active=true]:bg-primary data-[active=true]:text-slate-800",
                            ),
                            html.Button(
                                "Filled",
                                id="orders-filter-filled",
                                className="px-4 py-1.5 text-sm rounded-md transition-all hover:bg-primary/20 data-[active=true]:bg-primary data-[active=true]:text-slate-800",
                            ),
                        ],
                    ),
                ],
            ),
            
            # DataTable
            dash_table.DataTable(
                id="orders-blotter",
                columns=[
                    {"name": "Time", "id": "timestamp"},
                    {"name": "ClOrdId", "id": "clOrdId"},
                    {"name": "Symbol", "id": "symbol"},
                    {"name": "Side", "id": "side"},
                    {"name": "Type", "id": "orderType"},
                    {"name": "Qty", "id": "quantity"},
                    {"name": "Price", "id": "price"},
                    {"name": "Filled", "id": "filledQuantity"},
                    {"name": "Remaining", "id": "leavesQuantity"},
                    {"name": "Status", "id": "status"},
                ],
                data=[],
                row_selectable="single",
                page_size=10,
                sort_action="native",
                sort_by=[{"column_id": "timestamp", "direction": "desc"}],
                style_table={
                    "overflowX": "auto",
                    "borderRadius": "0.375rem",
                    "border": "none",
                },
                style_cell={
                    "padding": "12px 14px",
                    "fontFamily": "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', monospace",
                    "fontSize": "12px",
                    "borderBottom": "1px solid rgba(0,0,0,0.06)",
                    "borderRight": "1px solid rgba(0,0,0,0.03)",
                    "backgroundColor": "transparent",
                    "color": "#1e293b",
                    "textAlign": "left",
                    "whiteSpace": "nowrap",
                },
                style_header={
                    "fontWeight": "800",
                    "textTransform": "uppercase",
                    "fontSize": "10px",
                    "letterSpacing": "0.6px",
                    "borderBottom": "1px solid rgba(0,0,0,0.08)",
                    "borderRight": "1px solid rgba(0,0,0,0.08)",
                    "backgroundColor": "rgba(0,0,0,0.03)",
                    "color": "rgba(15,23,42,0.85)",
                    "padding": "14px",
                },
                style_data_conditional=[
                    {"if": {"filter_query": "{side} = BUY"}, "color": "#00d4aa", "fontWeight": "700"},
                    {"if": {"filter_query": "{side} = SELL"}, "color": "#ff6b6b", "fontWeight": "700"},
                    {"if": {"filter_query": "{status} = FILLED"}, "backgroundColor": "rgba(0, 212, 170, 0.08)"},
                    {"if": {"filter_query": "{status} = PARTIALLY_FILLED"}, "backgroundColor": "rgba(255, 217, 61, 0.08)"},
                    {"if": {"filter_query": "{status} = CANCELLED"}, "backgroundColor": "rgba(180, 180, 180, 0.05)"},
                    {"if": {"filter_query": "{status} = REPLACED"}, "backgroundColor": "rgba(77, 171, 247, 0.08)"},
                    {"if": {"filter_query": "{status} = REJECTED"}, "backgroundColor": "rgba(255, 107, 107, 0.08)"},
                    {"if": {"state": "selected"}, "backgroundColor": "rgba(77, 171, 247, 0.15)", "border": "1px solid rgba(77,171,247,0.5)"},
                    {"if": {"row_index": "odd"}, "backgroundColor": "rgba(0,0,0,0.02)"},
                ],
                style_data={
                    "height": "auto",
                    "lineHeight": "1.4",
                },
            ),
        ],
    )


def executions_blotter():
    """Redesigned executions blotter"""
    return html.Div(
        className="bg-white border border-light-200 rounded-lg p-5 shadow-md card-hover",
        children=[
            # Header with clear button
            html.Div(
                className="flex flex-wrap items-center justify-between mb-5 pb-3 border-b border-light-200 gap-3",
                children=[
                    html.Div(
                        className="flex items-center gap-2",
                        children=[
                            html.I(className="fa-solid fa-right-left text-primary"),
                            html.Span("Execution Reports", className="font-bold text-lg")
                        ],
                    ),
                    html.Button(
                        "Clear",
                        id="clear-executions-btn",
                        className="bg-light-100 hover:bg-light-200 text-light-500 font-semibold py-1.5 px-4 rounded-md text-sm shadow-sm hover:shadow-md transition-all active:scale-95",
                    ),
                ],
            ),
            
            dash_table.DataTable(
                id="executions-blotter",
                columns=[
                    {"name": "Time", "id": "timestamp"},
                    {"name": "ExecId", "id": "execId"},
                    {"name": "ClOrdId", "id": "clOrdId"},
                    {"name": "OrigClOrdId", "id": "origClOrdId"},
                    {"name": "Symbol", "id": "symbol"},
                    {"name": "Side", "id": "side"},
                    {"name": "ExecType", "id": "execType"},
                    {"name": "LastQty", "id": "lastQuantity"},
                    {"name": "LastPx", "id": "lastPrice"},
                    {"name": "CumQty", "id": "cumQuantity"},
                    {"name": "AvgPx", "id": "avgPrice"},
                    {"name": "Status", "id": "orderStatus"},
                ],
                data=[],
                page_size=8,
                sort_action="native",
                sort_by=[{"column_id": "timestamp", "direction": "desc"}],
                style_table={
                    "overflowX": "auto",
                    "borderRadius": "0.375rem",
                    "border": "none",
                },
                style_cell={
                    "padding": "10px 12px",
                    "fontFamily": "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', monospace",
                    "fontSize": "11px",
                    "borderBottom": "1px solid rgba(0,0,0,0.06)",
                    "borderRight": "1px solid rgba(0,0,0,0.03)",
                    "backgroundColor": "transparent",
                    "color": "#1e293b",
                    "textAlign": "left",
                    "whiteSpace": "nowrap",
                },
                style_header={
                    "fontWeight": "800",
                    "textTransform": "uppercase",
                    "fontSize": "10px",
                    "letterSpacing": "0.6px",
                    "borderBottom": "1px solid rgba(0,0,0,0.08)",
                    "borderRight": "1px solid rgba(0,0,0,0.08)",
                    "backgroundColor": "rgba(0,0,0,0.03)",
                    "color": "rgba(15,23,42,0.85)",
                    "padding": "12px",
                },
                style_data_conditional=[
                    {"if": {"filter_query": "{side} = BUY"}, "color": "#00d4aa", "fontWeight": "700"},
                    {"if": {"filter_query": "{side} = SELL"}, "color": "#ff6b6b", "fontWeight": "700"},
                    {"if": {"filter_query": "{execType} = FILL"}, "backgroundColor": "rgba(0, 212, 170, 0.08)"},
                    {"if": {"filter_query": "{execType} = PARTIAL_FILL"}, "backgroundColor": "rgba(255, 217, 61, 0.08)"},
                    {"if": {"filter_query": "{execType} = CANCELLED"}, "backgroundColor": "rgba(180, 180, 180, 0.05)"},
                    {"if": {"filter_query": "{execType} = REPLACED"}, "backgroundColor": "rgba(77, 171, 247, 0.08)"},
                    {"if": {"filter_query": "{execType} = REJECTED"}, "backgroundColor": "rgba(255, 107, 107, 0.08)"},
                    {"if": {"row_index": "odd"}, "backgroundColor": "rgba(0,0,0,0.02)"},
                ],
                style_data={
                    "height": "auto",
                    "lineHeight": "1.4",
                },
            ),
        ],
    )


def footer_bar():
    """Enhanced footer with better styling"""
    return html.Div(
        className="border-t border-light-200 bg-white py-3 px-6 mt-auto",
        children=html.Div(
            className="container mx-auto flex flex-wrap items-center justify-between text-xs text-light-400 gap-2",
            children=[
                html.Span("FIX OEMS v1.0 | Connected to localhost:8081"),
                html.Span(id="footer-session-info", className="font-mono"),
            ],
        ),
    )

# =============================================================================
# Main Layout
# =============================================================================

app.layout = html.Div(
    className="bg-light-100 text-slate-800 min-h-screen flex flex-col",
    children=[
        dcc.Interval(id="refresh-interval", interval=REFRESH_MS, n_intervals=0),
        dcc.Store(id="modal-open", data=False),   # controls modal visibility
        
        # Top bar
        top_bar(),
        
        # Main content area
        html.Div(
            className="container mx-auto flex-1 p-6",
            children=[
                # Stats row
                stats_row(),
                
                # Responsive grid layout
                html.Div(
                    className="grid grid-cols-1 lg:grid-cols-12 gap-6",
                    children=[
                        # Left column (now only order entry panel)
                        html.Div(
                            className="lg:col-span-3 space-y-6",
                            children=[order_entry_panel()],
                        ),
                        
                        # Right column (blotters)
                        html.Div(
                            className="lg:col-span-9 space-y-6",
                            children=[
                                orders_blotter(),
                                executions_blotter(),
                            ],
                        ),
                    ],
                ),
            ],
        ),
        
        # Footer
        footer_bar(),
        
        # Modal for Order Actions (hidden by default)
        html.Div(
            id="order-actions-modal",
            className="fixed inset-0 bg-slate-800 bg-opacity-40 flex items-center justify-center z-50",
            style={"display": "none"},
            children=[
                html.Div(
                    className="bg-white border border-light-200 rounded-lg p-5 shadow-xl w-full max-w-md",
                    children=[
                        # Header with close button
                        html.Div(
                            className="flex justify-between items-center mb-4 pb-2 border-b border-light-200",
                            children=[
                                html.Span("Order Actions", className="font-bold text-lg"),
                                html.Button(
                                    html.I(className="fa-solid fa-times"),
                                    id="modal-close-btn",
                                    className="text-light-400 hover:text-slate-800 transition-colors"
                                ),
                            ],
                        ),
                        # Selected order info (two columns)
                        html.Div(className="grid grid-cols-2 gap-4 mb-4", children=[
                            html.Div([
                                html.Label("ClOrdId", className="block text-xs text-light-400 mb-2 font-semibold"),
                                dcc.Input(id="action-clordid", disabled=True, className="w-full bg-light-100/70 border border-light-300 rounded-md px-3 py-2 text-slate-800 opacity-80 cursor-not-allowed"),
                            ]),
                            html.Div([
                                html.Label("Symbol", className="block text-xs text-light-400 mb-2 font-semibold"),
                                dcc.Input(id="action-symbol", disabled=True, className="w-full bg-light-100/70 border border-light-300 rounded-md px-3 py-2 text-slate-800 opacity-80 cursor-not-allowed"),
                            ]),
                        ]),
                        # Side + New Qty + New Price (three columns)
                        html.Div(className="grid grid-cols-3 gap-4 mb-4", children=[
                            html.Div([
                                html.Label("Side", className="block text-xs text-light-400 mb-2 font-semibold"),
                                dcc.Input(id="action-side", disabled=True, className="w-full bg-light-100/70 border border-light-300 rounded-md px-3 py-2 text-slate-800 opacity-80 cursor-not-allowed"),
                            ]),
                            html.Div([
                                html.Label("New Qty", className="block text-xs text-light-400 mb-2 font-semibold"),
                                dcc.Input(id="amend-qty", type="number", min="1", step="1", placeholder="New Qty", className="w-full bg-light-100 border border-light-300 rounded-md px-3 py-2 text-slate-800 focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all"),
                            ]),
                            html.Div([
                                html.Label("New Price", className="block text-xs text-light-400 mb-2 font-semibold"),
                                dcc.Input(id="amend-price", type="number", min="0", step="0.01", placeholder="New Price", className="w-full bg-light-100 border border-light-300 rounded-md px-3 py-2 text-slate-800 focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all"),
                            ]),
                        ]),
                        # Amend/Cancel buttons
                        html.Div(className="grid grid-cols-2 gap-4 mb-3", children=[
                            html.Button("Amend", id="amend-btn", className="bg-warning hover:bg-warning/90 text-white font-bold py-2.5 px-4 rounded-md shadow-sm hover:shadow-md transition-all active:scale-95"),
                            html.Button("Cancel", id="cancel-btn", className="bg-danger hover:bg-danger/90 text-slate-800 font-bold py-2.5 px-4 rounded-md shadow-sm hover:shadow-md transition-all active:scale-95"),
                        ]),
                        # Status message
                        html.Div(id="action-status-msg", className="mt-2 text-sm rounded-md p-2"),
                    ],
                )
            ],
        ),
    ],
)

# =============================================================================
# Callbacks (unchanged except for modal control)
# =============================================================================

@callback(Output("header-time", "children"), Input("refresh-interval", "n_intervals"))
def update_time(_n):
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


@callback(
    Output("connection-badge", "children"),
    Output("connection-badge", "className"),
    Output("footer-session-info", "children"),
    Input("refresh-interval", "n_intervals"),
)
def update_connection_status(_n):
    sessions = safe_get_json(f"{API_BASE_URL}/sessions", timeout=2)
    if sessions and any(s.get("loggedOn") for s in sessions):
        logged_sessions = [s for s in sessions if s.get("loggedOn")]
        s = logged_sessions[0]
        footer = f"Session: {s.get('senderCompId')} → {s.get('targetCompId')}"
        badge_text = f"CONNECTED ({len(logged_sessions)} session{'s' if len(logged_sessions) > 1 else ''})"
        return badge_text, "bg-success text-slate-800 text-xs font-semibold px-4 py-1.5 rounded-full shadow-sm", footer
    return "DISCONNECTED", "bg-danger text-slate-800 text-xs font-semibold px-4 py-1.5 rounded-full shadow-sm", "No active session"


@callback(
    Output("stat-orders", "children"),
    Output("stat-filled", "children"),
    Output("stat-partial", "children"),
    Output("stat-open", "children"),
    Output("stat-cancelled", "children"),
    Output("stat-rejected", "children"),
    Input("refresh-interval", "n_intervals"),
)
def update_stats(_n):
    orders = safe_get_json(f"{API_BASE_URL}/orders", timeout=2) or []
    total = len(orders)
    filled = sum(1 for o in orders if (o.get("status") or "").upper() == "FILLED")
    partial = sum(1 for o in orders if (o.get("status") or "").upper() == "PARTIALLY_FILLED")
    working = sum(
        1 for o in orders
        if (o.get("status") or "").upper() in (
            "NEW", "PENDING", "PENDING_REPLACE", "PENDING_NEW", "PENDING_CANCEL", "PARTIALLY_FILLED"
        )
    )
    cancelled = sum(1 for o in orders if (o.get("status") or "").upper() in ("CANCELLED", "REPLACED"))
    rejected = sum(1 for o in orders if (o.get("status") or "").upper() == "REJECTED")
    return str(total), str(filled), str(partial), str(working), str(cancelled), str(rejected)


# Networks that require OnBehalfOfCompID (tag 115)
ONBEHALF_NETWORKS = {"NYFIX", "TRADEWARE", "TRADEWEB"}


@callback(
    Output("broker-code-wrapper", "style"),
    Output("uuid-wrapper",        "style"),
    Output("onbehalf-wrapper",    "style"),
    Output("broker-code-select",  "value"),
    Output("onbehalf-input",      "value"),
    Input("network-select", "value"),
)
def toggle_network_fields(network):
    """Show/hide conditional fields based on selected network."""
    hidden  = {"display": "none"}
    visible = {"display": "block"}

    if network == "BLOOMBERG":
        return visible, visible, hidden, None, ""
    elif network in ONBEHALF_NETWORKS:
        return hidden, hidden, visible, None, ""
    else:
        # Sungard, Fidessa, CRD — no extra fields
        return hidden, hidden, hidden, None, ""


@callback(
    Output("uuid-input", "value"),
    Input("uuid-generate-btn", "n_clicks"),
    State("uuid-input", "value"),
    prevent_initial_call=False,
)
def generate_uuid(n_clicks, current_value):
    """Auto-populate UUID on load; regenerate when button is clicked."""
    if not current_value or n_clicks:
        return str(_uuid_lib.uuid4())
    return current_value


@callback(
    Output("order-status-msg", "children"),
    Input("buy-btn", "n_clicks"),
    Input("sell-btn", "n_clicks"),
    State("symbol-input",       "value"),
    State("quantity-input",     "value"),
    State("price-input",        "value"),
    State("order-type-select",  "value"),
    State("network-select",     "value"),
    State("broker-code-select",   "value"),
    State("uuid-input",           "value"),
    State("onbehalf-input",       "value"),
    State("prog-trading-toggle",  "value"),
    State("instr-type-store",     "data"),
    State("currency-select",      "value"),
    prevent_initial_call=True,
)
def submit_order(_buy, _sell, symbol, quantity, price, order_type,
                 network, broker_code, uuid_val, onbehalf_val,
                 prog_trading, instr_type, currency):
    if not ctx.triggered:
        return ""

    triggered_id = ctx.triggered[0]["prop_id"].split(".")[0]
    side = "BUY" if triggered_id == "buy-btn" else "SELL"

    if not symbol or not quantity:
        return html.Div("⚠ Enter symbol and quantity", className="bg-warning/20 text-warning p-2 rounded-md text-sm")

    order_type = (order_type or "LIMIT").upper()
    if order_type == "LIMIT" and (price is None or price == ""):
        return html.Div("⚠ Enter price for limit order", className="bg-warning/20 text-warning p-2 rounded-md text-sm")

    # Bloomberg-specific validation
    if network == "BLOOMBERG":
        if not broker_code:
            return html.Div("⚠ Broker Code is required for Bloomberg", className="bg-warning/20 text-warning p-2 rounded-md text-sm")
        if not uuid_val or not uuid_val.strip():
            return html.Div("⚠ Bloomberg UUID is required", className="bg-warning/20 text-warning p-2 rounded-md text-sm")

    # OnBehalfOfCompID-required networks validation
    if network in ONBEHALF_NETWORKS and (not onbehalf_val or not onbehalf_val.strip()):
        return html.Div(f"⚠ OnBehalfOfCompID (tag 115) is required for {network}", className="bg-warning/20 text-warning p-2 rounded-md text-sm")

    payload = {
        "symbol":    str(symbol).upper(),
        "side":      side,
        "orderType": order_type,
        "quantity":  int(quantity),
    }
    if order_type == "LIMIT":
        payload["price"] = float(price)
    if network:
        payload["network"] = network
    if broker_code:
        payload["brokerCode"] = broker_code
    if uuid_val and uuid_val.strip():
        payload["uuid"] = uuid_val.strip()
    if onbehalf_val and onbehalf_val.strip():
        payload["onBehalfOfCompId"] = onbehalf_val.strip()
    if prog_trading:
        payload["programmTrading"] = True
    if instr_type:
        payload["instrType"] = instr_type
    if currency:
        payload["currency"] = currency

    try:
        r = requests.post(f"{API_BASE_URL}/orders", json=payload, timeout=5)
        if r.status_code == 200:
            cid = r.json().get("clOrdId")
            bg_color   = "bg-success/20" if side == "BUY" else "bg-danger/20"
            text_color = "text-success"  if side == "BUY" else "text-danger"
            parts = [f"✓ {side} order sent: {cid}"]
            if network:
                parts.append(f"via {network}")
            if broker_code:
                parts.append(broker_code)
            if onbehalf_val and onbehalf_val.strip():
                parts.append(f"[115: {onbehalf_val.strip()}]")
            if instr_type:
                parts.append(f"[{instr_type}]")
            if currency:
                parts.append(f"[{currency}]")
            if prog_trading:
                parts.append("[PROG]")
            return html.Div(" ".join(parts), className=f"{bg_color} {text_color} p-2 rounded-md text-sm font-mono")
        err = r.json().get("message", "Order failed")
        return html.Div(f"✗ {err}", className="bg-danger/20 text-danger p-2 rounded-md text-sm")
    except Exception as e:
        return html.Div(f"Error: {str(e)}", className="bg-danger/20 text-danger p-2 rounded-md text-sm")


@callback(
    Output("instr-type-store", "data"),
    Output("instr-cs-btn",  "className"),
    Output("instr-etf-btn", "className"),
    Input("instr-cs-btn",  "n_clicks"),
    Input("instr-etf-btn", "n_clicks"),
    prevent_initial_call=True,
)
def toggle_instr_type(_cs, _etf):
    active   = "flex-1 py-1.5 text-xs font-bold rounded-md transition-all bg-primary text-slate-800"
    inactive = "flex-1 py-1.5 text-xs font-bold rounded-md transition-all hover:bg-primary/20 text-light-400"
    triggered = ctx.triggered_id
    if triggered == "instr-etf-btn":
        return "ETF", inactive, active
    return "CS", active, inactive


@callback(
    Output("orders-blotter", "data"),
    Input("refresh-interval", "n_intervals"),
    Input("orders-filter-all", "n_clicks"),
    Input("orders-filter-working", "n_clicks"),
    Input("orders-filter-filled", "n_clicks"),
)
def refresh_orders(_n, *args):
    triggered = ctx.triggered_id
    if triggered == "orders-filter-working":
        filter_value = "working"
    elif triggered == "orders-filter-filled":
        filter_value = "filled"
    else:
        filter_value = "all"

    orders = safe_get_json(f"{API_BASE_URL}/orders", timeout=2) or []
    fv = filter_value.lower()

    if fv == "working":
        orders = [
            o for o in orders
            if (o.get("status") or "").upper() in ("NEW", "PENDING", "PARTIALLY_FILLED", "PENDING_REPLACE", "PENDING_NEW", "PENDING_CANCEL")
        ]
    elif fv == "filled":
        orders = [o for o in orders if (o.get("status") or "").upper() == "FILLED"]

    return normalize_orders_for_table(orders)


@callback(Output("executions-blotter", "data"), Input("refresh-interval", "n_intervals"))
def refresh_executions(_n):
    execs = safe_get_json(f"{API_BASE_URL}/executions?limit=50", timeout=2) or []
    return normalize_execs_for_table(execs)


@callback(
    Output("action-clordid", "value"),
    Output("action-symbol", "value"),
    Output("action-side", "value"),
    Output("amend-qty", "value"),
    Output("amend-price", "value"),
    Input("orders-blotter", "selected_rows"),
    State("orders-blotter", "data"),
    prevent_initial_call=True,
)
def select_order(selected_rows, data):
    if selected_rows and data:
        row = data[selected_rows[0]]
        price = None
        if row.get("price") and row["price"] != "MKT":
            try:
                price = float(str(row["price"]).replace("$", ""))
            except Exception:
                price = None
        return row.get("clOrdId", ""), row.get("symbol", ""), row.get("side", ""), row.get("quantity", ""), price
    return "", "", "", "", ""


@callback(
    Output("action-status-msg", "children"),
    Input("cancel-btn", "n_clicks"),
    Input("amend-btn", "n_clicks"),
    State("action-clordid", "value"),
    State("action-symbol", "value"),
    State("action-side", "value"),
    State("amend-qty", "value"),
    State("amend-price", "value"),
    prevent_initial_call=True,
)
def handle_order_action(_cancel, _amend, clordid, symbol, side, new_qty, new_price):
    if not ctx.triggered or not clordid:
        return html.Div("Select an order first", className="bg-warning/20 text-warning p-2 rounded-md text-sm")

    triggered_id = ctx.triggered[0]["prop_id"].split(".")[0]

    try:
        if triggered_id == "cancel-btn":
            r = requests.delete(
                f"{API_BASE_URL}/orders/{clordid}",
                params={"symbol": symbol, "side": side},
                timeout=5,
            )
            if r.status_code == 200:
                return html.Div("✓ Cancel sent", className="bg-primary/20 text-primary p-2 rounded-md text-sm")
            return html.Div("Cancel failed", className="bg-danger/20 text-danger p-2 rounded-md text-sm")

        if triggered_id == "amend-btn":
            if not new_qty and not new_price:
                return html.Div("Enter new qty or price", className="bg-warning/20 text-warning p-2 rounded-md text-sm")

            payload = {"symbol": symbol, "side": side}
            if new_qty:
                payload["newQuantity"] = int(new_qty)
            if new_price:
                payload["newPrice"] = float(new_price)

            r = requests.put(f"{API_BASE_URL}/orders/{clordid}", json=payload, timeout=5)
            if r.status_code == 200:
                return html.Div("✓ Amend sent", className="bg-primary/20 text-primary p-2 rounded-md text-sm")
            return html.Div("Amend failed", className="bg-danger/20 text-danger p-2 rounded-md text-sm")

        return html.Div("Request failed", className="bg-danger/20 text-danger p-2 rounded-md text-sm")
    except Exception as e:
        return html.Div(f"Error: {str(e)}", className="bg-danger/20 text-danger p-2 rounded-md text-sm")


@callback(
    Output("executions-blotter", "data", allow_duplicate=True),
    Input("clear-executions-btn", "n_clicks"),
    prevent_initial_call=True,
)
def clear_executions(_n):
    try:
        requests.delete(f"{API_BASE_URL}/executions", timeout=2)
    except Exception:
        pass
    return []


# =============================================================================
# Modal control callbacks
# =============================================================================

@callback(
    Output("order-actions-modal", "style"),
    Input("modal-open", "data"),
)
def toggle_modal(open_flag):
    if open_flag:
        return {"display": "flex"}
    return {"display": "none"}


@callback(
    Output("modal-open", "data"),
    Input("orders-blotter", "selected_rows"),
    prevent_initial_call=True,
)
def open_modal_on_select(selected_rows):
    return bool(selected_rows and len(selected_rows) > 0)


@callback(
    Output("modal-open", "data", allow_duplicate=True),
    Output("orders-blotter", "selected_rows"),
    Input("modal-close-btn", "n_clicks"),
    prevent_initial_call=True,
)
def close_modal(_):
    return False, []


if __name__ == "__main__":
    print("=" * 60)
    print("  FIX OEMS - Order & Execution Management System (Tailwind)")
    print("=" * 60)
    print(f"  API: {API_BASE_URL}")
    print("  UI:  http://localhost:8050")
    print("=" * 60)
    app.run(debug=True, host="0.0.0.0", port=8050)
